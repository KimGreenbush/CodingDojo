namespace RandomPasscode
{
    public class Count
    {
        public int Counter { get; set;}
    }
}